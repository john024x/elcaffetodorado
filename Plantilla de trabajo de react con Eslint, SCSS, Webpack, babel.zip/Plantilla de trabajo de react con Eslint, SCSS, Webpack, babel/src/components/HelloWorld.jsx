import React from 'react';
import '../assets/styles/app.scss'


const Hello = () =>(
    <h1>
        GG
    </h1>
)

export default Hello;